#! -*- coding:utf8 -*-

def gen_sqla():
    print 'hello world'


if __name__ == "__main__":
    print 'hello'
