#! -*- coding:utf8 -*-

def gen_test():
    gen_orm_model.gen()
