from setuptools import setup

setup(name='clinicaltrial',
      version='0.0.1',
      description='a generate sqlarchemy models utils',
      url='https://github.com/SUT-GC/gen-sqla-orm',
      author='gouchao',
      author_email='sutgouc@gmail.com',
      license='MIT',
      zip_safe=False)
